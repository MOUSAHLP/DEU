<?php

namespace App\Models;

class Faq extends NoDeleteBaseModel
{
    
}
