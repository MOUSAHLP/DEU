<?php

namespace App\Http\Livewire\Report;

use App\Http\Livewire\BaseLivewireComponent;

class LoyaltyReportLivewire extends BaseLivewireComponent
{


    public function render()
    {
        return view('livewire.reports.loyalty_report');
    }


}
